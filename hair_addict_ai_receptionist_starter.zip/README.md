Starter kit for Hair Addict AI Receptionist.
